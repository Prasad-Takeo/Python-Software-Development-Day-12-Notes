# ## Exception Handling
# ## Error in Python can be of two types Syntax Error and Exceptions.
# ## Errors are the problems in the program due to which the program will stop execution.
# ## on the other hand, exceptions are raised when some internal events occur which
# ## changes the normal flow of the program
#
# ## try except block
# ## try except else block
# ## try except else finally block
# ## raise Exception
#
# ## difference between syntax error and exceptions:
# #syntax error - caused by the wrong syntax in the code, it leads to the termination of the program
# # amount = 10000
# # if amount > 10000
# # print("it's higher")
#
# #Exceptions: are raised when the program is syntactically correct, but the code resulted in an error.
# # try:
# #     marks = 10000
# #     a  = marks/0
# #     print(a)
# # except:
# #     print("The code resulted in an exception")
#
# """
# try
#   run this code
# except:
#   execute this code when there is an exception
# else:
#   No exceptions? run this code
# finally:
#   always run this code
# """
# #
# # try:
# #     a = [1,2,3]
# #     print(a[3])
# # except IndexError as e:
# #     print("Index Error:",e)
# # except ValueError as e:
# #     print("Value Error:",e)
# # except Exception as e:
# #     print("General Base Exception:",e)
# # finally:
# #     print("I'm finally done")
# #
# #
# # try:
# #     a = [1,2,3]
# #     print(a.remove(8))
# # except IndexError as e:
# #     print("Index Error:",e)
# # except ValueError as e:
# #     print("Value Error:",e)
# # except Exception as e:
# #     print("General Base Exception:",e)
# # finally:
# #     print("I'm finally done")
# #
# # try:
# #     a = input("enter the number:")
# #     if a < 4:
# #         raise Exception("Cannot access 4th element as the length is short")
# #     else:
# #         print(a)
# #     except IndexError as e:
# #         print("Index Error:",e)
# #     except ValueError as e:
# #         print("Value Error:",e)
# #     except TypeError as e:
# #         print("Type Error:", e)
# #         print("Give the numeric value")
# #     except Exception as e:
# #         print("General Base Exception:",e)
# #     else:
# #         print("There is no exception")
# #     finally:
# #         print("I'm finally done")
#
# #program to get 10 inputs from the user and if the input is not able to convert to integer,
# #raise the exception and handle it
#
# # try:
# #     for i in range(0, 10):
# #         num = int(input('Enter Number:'))
# # except ValueError as e:
# #     print("Value Error: ",e)
# # else:
# #     print("There is no exception")
# # finally:
# #     print("You are done")
#
# # try:
# #     i = 0
# #     while i < 10:
# #         user_input = int(input("enter the number:"))
# #         i += 1
# #         # if not user_input.isnumeric():
# #         #     raise Exception("The given input is not number")
# # except Exception as e:
# #     print("An Exception Occured,", e)
# # else:
# #     print("User Inputs completed")
# # finally:
# #     print("Good Bye")
#
# ##custom error class
# # class MyError(Exception):
# #     def __init__(self,value):
# #         self.value = value
# #
# #     #__str__, __repr__ is to print() the value
# #     def __repr__(self):
# #         return(self.value)
# #
# # try:
# #     raise MyError(3*2)
# # except MyError as error:
# #     print("A New Exception Occured: ",error.value)
#
#
# ### the program will ask the user to enter a number until they guess a started number correctly.
# ### To help them figure out,a hint is provided whether their guess is greater than or less than the
# ### stored number
# class Error(Exception):
#     pass
#
# class ValueTooSmallError(Error):
#     pass
#
# class ValueTooLargeError(Error):
#     pass
#
# number = 10
# while True:
#     try:
#         i_num = int(input("Enter a number:")) #11
#         if i_num < number:
#             raise ValueTooSmallError
#         elif i_num > number:
#             raise ValueTooLargeError
#         break
#     except ValueTooSmallError:
#         print("This value is too small. try again!")
#         print()
#     except ValueTooLargeError:
#         print("This value is too large. try again!")
#         print()
#     except Exception as e:
#         print("General Exception Occured, ",e)
#         print()
#
# print("You find it")

## we will ask for a salary to the user and if the salary is not beween 5000 to 15000 raise exception,
## create a custom salaryException class

class SalaryNotInRangeError(Exception):
    def __init__(self,salary, message="Salary is not in (5000,15000) range"):
        self.salary = salary
        self.message = message
        super().__init__(self.message)

    def __str__(self):
        return f"{self.salary} -> {self.message}"

salary = int(input("Enter the salary amount:"))
if not 5000 < salary < 15000: #if not salary > 5000 and salary < 15000
    try:
        err = SalaryNotInRangeError(salary)
        raise err
    except Exception as e:
        print("Custom Exception Handled: ", e.message)
