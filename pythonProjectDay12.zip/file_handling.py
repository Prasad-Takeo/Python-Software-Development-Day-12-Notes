#file operations using python
#open, create, read, write, delete, append, close
#syntax of opening a file
# f = open(filename,mode)
# filename - absolute file path
# mode -
"""
r - open an existing file for read operation
w - open an existing file for the write operation.
    if the file already contains some data then it will be overridden
a - open an existing file for append operation. it won't override existing data
r+ -  to read and write data into the file. The previous data in the file will not be deleted
w+ - to write and read data, it will override existing data
a+ - to append and read from the file, it won't override existing data
"""

# f =  open("sample.csv","r+")
# print(f.read())
#
# f= open("sample.csv","a")
# f.write("test3")


###Program to create a sample.csv file with firstname,lastname of 3 person
###

# f=open("sample2.csv", "w")
# f.write("firstname, lastname \n")
# f.write("Ram, Kaji \n")
# f.write("Shyam, Kumar \n")
# f.write("Hari, Prasad \n")
# f.close()

#context manager in python, __entry__ and __exit__ magic method
with open("sample2.csv","w") as f:
    f.write("firstname, lastname \nRam, Kaji \nShyam, Kumar \nHari, Prasad \n")

##program to write excel - openpyxl library - https://worldweather.wmo.int/en/json/full_city_list.txt
## open the https://worldweather.wmo.int/en/json/full_city_list.txt (download) file and read
## create the excel file using openpyxl
## https://pypi.org/project/openpyxl/

import requests
data = requests.get("https://worldweather.wmo.int/en/json/full_city_list.txt")
print(data.text)